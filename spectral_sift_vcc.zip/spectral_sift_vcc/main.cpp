#include <stdio.h>
#include <time.h>
#include <opencv2/opencv.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/nonfree/nonfree.hpp>
#include "eigen_filter.h"
#include "keypoint.h"
#include "spectral_sift.h"
using namespace cv;


//******************************************************************************
// Previous SIFT
//******************************************************************************
void run_sift(
	char *filename, 
	int L, 
	keypoint_t *keypoints, int &num
	){

	Mat in = imread(filename);

	// Pre-filtering
	float sigma = sqrt(1.51 * 1.51 - 1.0 * 1.0);
	cv::GaussianBlur(in, in, cv::Size(), sigma, sigma);

	std::vector<cv::KeyPoint> keypts;

	clock_t t0 = clock();

	//*******************************************************
	// Run detection
	cv::SiftFeatureDetector detector(0, L, 0.07, 10, 1.6);
	detector.detect(in, keypts);
	//*******************************************************


	//*******************************************************
	// Output results
	//*******************************************************
	int tw = clock() - t0;

	printf("%d detected. time=%d[msec], time/keypoint=%.4f\n", keypts.size(), tw, tw / (float)(keypts.size()) );

	num = 0;
	for(int i = 0;i < keypts.size();i++){

		keypts[i].size /= 2.0;
		keypoints[num].x = keypts[i].pt.x;
		keypoints[num].y = keypts[i].pt.y;
		keypoints[num].s = keypts[i].size;
		keypoints[num].amp = keypts[i].response;

		num++;
		//}
	}	
}

//******************************************************************************
// main routin
//******************************************************************************
int main(int argc, char *argv[]){

	int L = atoi(argv[3]);
	int w, h;

	//****************************************************
	// read input image and convert to gray scale image
	//****************************************************
	Mat out = imread(argv[1]), grayimg;
	w = out.cols;
	h = out.rows;	
	cvtColor( out, grayimg, CV_BGR2GRAY );


	//****************************************************************
	// Setup eigen filters
	//****************************************************************
	if(L == 0){
		// pre-filtering
		float sigma = sqrt(1.51 * 1.51 - 1.0 * 1.0);
		cv::GaussianBlur(grayimg, grayimg, cv::Size(), sigma, sigma);
		// setup
		int N = 25;// Eigen-Filter Size
		gen_eigen_filters(w, h, N);
	}
	keypoint_t *keypoints = new keypoint_t[10000];
	int num = 0;

	//****************************************************************
	//  Run Detection
	//****************************************************************
	if(L == 0){
		// Run Proposed Spectral SIFT
		run(grayimg.data, w, h, keypoints, num);
	} else {
		// Run Previous SIFT
		run_sift(argv[1], L, keypoints, num);
	}

	//****************************************************************
	// sort keypoint by the order of edge amplitude
	//****************************************************************
	std::sort(&keypoints[0], &keypoints[num]);
	// select 500 keypoints
	int min_num = 500;
	if(num >min_num)num = min_num;

	//****************************************************************
	//   Output Results
	//****************************************************************
	FILE *fp=fopen(argv[2], "w");
	fprintf(fp, "%d %d\n", num, 128);

	for(int i = 0;i < num;i++){
		real dx,dy,scl;
		dx  = keypoints[i].x;
		dy  = keypoints[i].y;
		scl = keypoints[i].s;
		cv::circle(out, cv::Point2d(dx,dy), 1.5 * scl, cv::Scalar(0,0,255));
		fprintf(fp, "%f %f %f 0\n", dy, dx, scl);
		for(int n = 0;n < 128;n++){
			fprintf(fp, "0 ");
		}
		fprintf(fp, "\n");
	}
	fclose(fp);
	imwrite(argv[4], out);


	//****************************************************************
	// Free works
	delete keypoints;

	return 0;
}
