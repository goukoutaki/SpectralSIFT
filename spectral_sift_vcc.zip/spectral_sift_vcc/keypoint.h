//
//
//
#ifndef _KEYPOINT_
#define _KEYPOINT_
#include <math.h>

typedef float real;

struct keypoint_t {
	real x, y, s;
	real dir;
	real des[128];
	real amp;
	int oct;
	int type;

	bool operator < (const keypoint_t & ref) const {
		return fabs(amp) > fabs(ref.amp);
	}
};

#endif
