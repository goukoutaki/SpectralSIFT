#define _USE_MATH_DEFINES
#include <math.h>
#include "fftw/fftw3.h"  //**** changed 2014/4/2 ****//
#include <string.h>

typedef float real;

#define FFTW_PLAN		 fftwf_plan
#define FFTW_COMPLEX 	 fftwf_complex
#define FFTW_EXCUTE		 fftwf_execute
#define FFTW_DFT		 fftwf_plan_dft_2d
#define FFTW_MALLOC		 fftwf_malloc
#define FFTW_FREE		 fftwf_free

int load_filter_and_FFT_from_file(char *filename, FFTW_COMPLEX * out, int w, int h, int N);

