#include "keypoint.h"
#include <opencv2/opencv.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/nonfree/nonfree.hpp>
using namespace cv;

int gen_eigen_filters(int w, int h, int N);
void run(unsigned char *in, int w, int h, keypoint_t *keypoints, int & num);