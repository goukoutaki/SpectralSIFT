//************************************************************************************
//
//  Spectral SIFT Detector Code
//
//  [1]"Scale-space Processing Using Polynomial Representations",
//     Gou Koutaki, Keiichi Uchimura (Kumamoto University), CVPR2014
//
//    Copyright (c) 2014, Gou Koutaki <koutaki@cs.kumamoto-u.ac.jp>
//    All rights reserved.
//
//************************************************************************************
#include <fftw/fftw3.h>
#include <time.h>
#include <algorithm>

#include "spectral_sift.h"
#include "eigen_filter.h"
#include "keypoint.h"


// SIFT parameters
real CURV_THR         = 10;
real EDGE_THR         = (CURV_THR+1.0)*(CURV_THR+1.0)/CURV_THR;
real SIFT_CONTR_THR   = 0.07;

#define EIGEN_FNUM	4	// num of basis functions
#define EIGEN_PNUM	4	// polynomial order
#define EIGEN_OCTN  8	// max octave number

//************************************************************
// global works
//************************************************************
// FFT buffer of input image
FFTW_COMPLEX  *fftw_f = NULL;
FFTW_COMPLEX  *fftw_F = NULL;
FFTW_PLAN fftwfPlan_F = NULL;
// Eigen filters
FFTW_COMPLEX *fftw_LOG[EIGEN_OCTN][EIGEN_FNUM]   = {NULL};// sLoG
// Filter plans
FFTW_PLAN  fftwfPlan_log[EIGEN_OCTN][EIGEN_FNUM] = {NULL};
// Convolution results of input and eigen-filters
FFTW_COMPLEX *fftw_FG[EIGEN_FNUM]    = {NULL};
// IFFT of filtered images
FFTW_COMPLEX   *fftw_log[EIGEN_FNUM] = {NULL};
// Co-Efficient images
real *filtered_img[EIGEN_PNUM];
real coef[EIGEN_FNUM][EIGEN_PNUM];
real QN[2] = {1.4, 3.4};
// mailbox of detected keypoints
unsigned char *roi = NULL;
unsigned char  roi_i = 1;
int in_w, in_h;

//********************************
// round 
//********************************
int round(real x){
	return (int)floor(x + 0.5);
}

//********************************
// free works
//********************************
void free_filters(){

	if(fftw_f){
		FFTW_FREE(fftw_f);	
		FFTW_FREE(fftw_F);	
		for(int i = 0;i < EIGEN_FNUM;i++){
			FFTW_FREE(fftw_LOG[i]);	
			FFTW_FREE(fftw_log[i]);	
		}
	}

	for(int j = 0;j < EIGEN_PNUM;j++){
		delete filtered_img[j];
	}

	if(roi)
		delete roi;
}

//***************************************************
// Convolve and IFFT
//***************************************************
void convolv_LOG(int i, int w, int h, int oct){
	int wh = w * h;
	for(int ptr = 0;ptr < wh;ptr++){
		// (x1 + iy1) (x2 - iy2) = x1x2+y1y1 + i(y1x2 - x1y2)
		fftw_FG[i][ptr][0] =  fftw_F[ptr][0] * fftw_LOG[oct][i][ptr][0] + fftw_F[ptr][1] * fftw_LOG[oct][i][ptr][1];
		fftw_FG[i][ptr][1] = -fftw_F[ptr][0] * fftw_LOG[oct][i][ptr][1] + fftw_F[ptr][1] * fftw_LOG[oct][i][ptr][0];
	}

	FFTW_EXCUTE(fftwfPlan_log[oct][i]);
}

//************************************************************************
// Setup Eigen-Filters from Files
//************************************************************************
int gen_eigen_filters(int w, int h, int N){

	char file[256];

	free_filters();

	fftw_f      = (FFTW_COMPLEX *)FFTW_MALLOC(sizeof(FFTW_COMPLEX)*w*h);
	fftw_F      = (FFTW_COMPLEX *)FFTW_MALLOC(sizeof(FFTW_COMPLEX)*w*h);

	for(int i = 0;i < EIGEN_FNUM;i++){
		fftw_FG[i]       = (FFTW_COMPLEX *)FFTW_MALLOC(sizeof(FFTW_COMPLEX)*w*h);

		//*****************************************
		// Load eigenfilter's co-efficent
		//*****************************************
		sprintf(file, "./filter/F%d.txt", i+1);
		int sw, sh;
		for(int oct = 0;oct < EIGEN_OCTN;oct++){
			sw = w >> oct;
			sh = h >> oct;

			fftw_LOG[oct][i]      = (FFTW_COMPLEX *)FFTW_MALLOC(sizeof(FFTW_COMPLEX)*sw*sh);
			load_filter_and_FFT_from_file(file, fftw_LOG[oct][i], sw, sh, N);
		}
		//****************************************
		// malloc filter images
		//****************************************
		fftw_log[i]      = (FFTW_COMPLEX *)FFTW_MALLOC(sizeof(FFTW_COMPLEX)*w*h);

		//****************************************
		// gen FFT plans
		//****************************************
		for(int oct = 0;oct < EIGEN_OCTN;oct++){
			sw = w >> oct;
			sh = h >> oct;
			fftwfPlan_log[oct][i] = FFTW_DFT(sh, sw, fftw_FG[i], fftw_log[i], FFTW_BACKWARD, FFTW_ESTIMATE);
		}

		// Load co-efficients of polynomial basis functions
		sprintf(file, "./filter/qdat%d.txt", i+1);
		FILE *fp=fopen(file,"r");
		for(int j = 0;j < EIGEN_PNUM;j++){
			fscanf(fp, "%f,", &coef[i][j]);
		}

		fclose(fp);

	} // i

	//****************************************
	// malloc filtered images
	//****************************************
	for(int j = 0;j < EIGEN_PNUM;j++){
		filtered_img[j] = new real[w * h];
	}

	//****************************************
	// Init mailbox
	//****************************************
	roi = new unsigned char[w * h];
	memset(roi, 0, w * h);
	roi_i = 1;
	in_w = w;
	in_h = h;

	return 0;
}

//***************************************************************
// Determine keypoint as detection 
//***************************************************************
int add_keypoint(
	int x, int y, int w, int h, 
	int ptr, real s, int sign,
	keypoint_t *keypoints, 
	int & num, 
	int oct
	){
	
	real delta_s = 0.04;
	real s2, s3;
	s2 =  s * s;
	s3 = s2 * s;

	real p0;
	p0 = filtered_img[0][ptr] + filtered_img[1][ptr] * s + filtered_img[2][ptr] * s2 + filtered_img[3][ptr] * s3;

	// Initial check by edge-threshold
	if(fabs(p0) < (0.5 * 255 * SIFT_CONTR_THR))
		return 0;

	if(sign > 0){
		//*********************************************
		// Check Bright Keypoint
		//*********************************************
		for(int ss = -1;ss <= 1;ss++){
			real ds  = s + ss * delta_s;
			real ds2 = ds  * ds; 
			real ds3 = ds2 * ds; 
			for(int sy = -1;sy <= 1;sy++){ 
				for(int sx = -1;sx <= 1;sx++){ 
					int sptr = (sx + x) + (sy + y ) * w; 
					real p = filtered_img[0][sptr] 
					       + filtered_img[1][sptr] * ds 
						   + filtered_img[2][sptr] * ds2 
					   	   + filtered_img[3][sptr] * ds3;
					if(p0 > p)
						return 0;
				}
			}
		}
	} else {
		//*********************************************
		// Check Dark Keypoint
		//*********************************************
		for(int ss = -1;ss <= 1;ss++){
			real ds  = s + ss * delta_s;
			real ds2 = ds  * ds; 
			real ds3 = ds2 * ds; 
			for(int sy = -1;sy <= 1;sy++){ 
				for(int sx = -1;sx <= 1;sx++){ 
					int sptr = (sx + x) + (sy + y ) * w; 
					real p = filtered_img[0][sptr] 
					       + filtered_img[1][sptr] * ds 
						   + filtered_img[2][sptr] * ds2 
						   + filtered_img[3][sptr] * ds3;
					if(p0 < p)
						return 0;
				}
			}
		}
	}

	//**************************************************************
	// Eliminate Edge-Like Keypoints by Hessian
	//**************************************************************
	real p1, p2, p3, p4, p5, p6, p7, p8;
	int it = 0;
	real mx, my;
	mx = x;
	my = y;

subpix:

	//************************************
	// Obtain sLoG amplitude
	//************************************
	ptr = x + 1 + y * w;
	p1  = filtered_img[0][ptr] + filtered_img[1][ptr] * s + filtered_img[2][ptr] * s2 + filtered_img[3][ptr] * s3;
	ptr -= w;
	p2  = filtered_img[0][ptr] + filtered_img[1][ptr] * s + filtered_img[2][ptr] * s2 + filtered_img[3][ptr] * s3;
	ptr -= 1;
	p3  = filtered_img[0][ptr] + filtered_img[1][ptr] * s + filtered_img[2][ptr] * s2 + filtered_img[3][ptr] * s3;
	ptr -= 1;
	p4  = filtered_img[0][ptr] + filtered_img[1][ptr] * s + filtered_img[2][ptr] * s2 + filtered_img[3][ptr] * s3;
	ptr += w;
	p5  = filtered_img[0][ptr] + filtered_img[1][ptr] * s + filtered_img[2][ptr] * s2 + filtered_img[3][ptr] * s3;
	ptr += w;
	p6  = filtered_img[0][ptr] + filtered_img[1][ptr] * s + filtered_img[2][ptr] * s2 + filtered_img[3][ptr] * s3;
	ptr += 1;
	p7  = filtered_img[0][ptr] + filtered_img[1][ptr] * s + filtered_img[2][ptr] * s2 + filtered_img[3][ptr] * s3;
	ptr += 1;
	p8  = filtered_img[0][ptr] + filtered_img[1][ptr] * s + filtered_img[2][ptr] * s2 + filtered_img[3][ptr] * s3;

	double dxx, dyy, dxy, tr, det, curv_thr = CURV_THR;
	dxx = p1 + p5 - 2 * p0;
	dyy = p3 + p7 - 2 * p0;
	dxy = (p8 - p2 - (p6 - p4) ) / 4.0;

	tr  = dxx + dyy;
	det = dxx * dyy - dxy * dxy;

	// Check Det of Hessian
	if(det <= 0)
		return 0;

	// Check Curvature of Keypoint
	if( (tr * tr / det) >= (( curv_thr + 1.0 )*( curv_thr + 1.0 ) / curv_thr) )
		return 0;

	//*****************************************************************************
	// Sub-pixel Displacement Adjustment of Keypoint by Fitting Quadric Surface
	// D=(axx+bxy+cyy+d+e-f(x,y))^2
	//*****************************************************************************
	double sub_x, sub_y, sub_p;
	double A,B,C,D,E, F, f;
	sub_x = sub_y = 0.0;

	A = (p1 + p2 - 2 * p3 + p4 + p5 + p6 - 2 * p7 + p8 - 2 * p0) / 6.0;
	B = (-p2 + p4 - p6 + p8) / 4.0;
	C = (-2 * p1 + p2 + p3 + p4 - 2 * p5 + p6 + p7 + p8 - 2 * p0) / 6.0;
	D = ( p1 + p2 - p4 - p5 - p6 + p8) / 6.0;
	E = (-p2 - p3 - p4 + p6 + p7 + p8) / 6.0;
	F = (2*p1-p2+2*p3-p4+2*p5-p6+2*p7-p8+5*p0) / 9.0;
	double dx, dy;
	dx = (p1 - p5)/2.0;
	dy = (p7 - p3)/2.0;
	f = (B * B - 4 * A * C);

	if(abs(f) > 0.0001)
	{
		sub_x = -(-2 * C * D + B * E) / f;
		sub_y = -( B * D - 2 * A * E) / f;
		sub_p = A * sub_x * sub_x + B * sub_x * sub_y + C * sub_y * sub_y + D * sub_x +E * sub_y + F;
		//********************************************
		// Re-Check Edge-Amplitude
		//********************************************
		if( 
			fabs(sub_p) < (255 * SIFT_CONTR_THR) ||
			fabs(sub_x) > 3.0 ||
			fabs(sub_y) > 3.0
			)
			return 0;
	} else
		return 0;

	it++;
	mx += sub_x;
	my += sub_y;
	x = round(mx);
	y = round(my);

	//**********************************************
	// Repeat Sub-pix Adjustment
	//**********************************************
	if(it < 5 )goto subpix;


	//**********************************************
	// Check Keypoint Add
	//**********************************************
	real scale = 1 << oct;
	int ix, iy, iptr;
	ix = round(mx * scale);
	iy = round(my * scale);
	iptr = ix + iy * in_w;
	int flg = 0;

	//**********************************************
	// Check Mailbox to Avoid Multiple Detections
	//**********************************************
	int S = 1;
	for(int sy = -S;sy <= S;sy++){
		for(int sx = -S;sx <= S;sx++){
			if(roi[iptr + sx + sy * in_w] == roi_i){
				flg = 1;
				goto END_LOOP;
			}
		} // sx
	} // sy

END_LOOP:


	//**********************************************
	// Keypoint Add
	//**********************************************
	if(flg == 0){
		keypoints[num].x = mx * scale;
		keypoints[num].y = my * scale;
		keypoints[num].s =  s * scale;
		keypoints[num].amp = sub_p;
		keypoints[num].oct = oct;
		num++;
		roi[iptr] = roi_i;
	}

	return 1;
}

int filtering_tw = 0;

//*******************************************************************************
// Detection Routine for One Octave
//*******************************************************************************
void detect(
	unsigned char *in, int w, int h,
	keypoint_t *keypoints, int & num, int oct
	){

	//***************************************************************************
	// (1) FFT of Input Image
	//***************************************************************************

	int t0 = clock();

	int ptr, wh;
	int n = 0;
	real norm;
	wh   = w * h;
	norm = 1.0 / wh;
	// Copy to FFT input buffer
	for(ptr = 0; ptr < wh; ptr++){
		fftw_f[ptr][0] = in[ptr] * norm;
		fftw_f[ptr][1] = 0.0;
	}
	// RUN FFT
	fftwfPlan_F =  FFTW_DFT(h, w, fftw_f, fftw_F, FFTW_FORWARD, FFTW_ESTIMATE);
	FFTW_EXCUTE(fftwfPlan_F);
	//***************************************************************************

	//***************************************************************************
	// (2) Convolve Input Image with Eigen Filters
	//***************************************************************************
#pragma omp parallel for
	for(int i = 0;i < EIGEN_FNUM;i++){
		convolv_LOG(i, w, h, oct);
	}


	//***************************************************************************
	// (3) Gen Co-efficient Images
	//***************************************************************************
#pragma omp parallel for
	for(int j = 0;j < EIGEN_PNUM;j++){
		for(int ptr = 0;ptr < wh;ptr++){
			real sum = 0.0;
			for(int i = 0;i < EIGEN_FNUM;i++){
				sum += coef[i][j] * fftw_log[i][ptr][0];
			}
			filtered_img[j][ptr] = sum;
		}
	}

	filtering_tw += (clock() - t0);

	//***************************************************************************
	// (4) Keypoints Detection by Extrema Check
	//***************************************************************************
	int B = 11;
	for(int y = B;y < h-B;y++){
		for(int x = B;x < w-B;x++, ptr++){
			ptr = x + y * w;

			// sLOG  = filtered_img[0][n] + filtered_img[1][n]*s + filtered_img[2][n]*s^2 + filtered_img[3][n] * s^3
			// sLOG' = filtered_img[1][n] + 2 filtered_img[2][n]*s + 3 filtered_img[3][n] * s^2 = a s^2+ bs + c
			// s = (-b += (b^2 - 4ac)^1/2)/ (2a)

			real a, b, c;
			real t1, t2;
			t1 = QN[n];t2 = QN[n+1];

			// log' =a*s*s + b*s+c
			// log''=2a*s  + b
			c =        filtered_img[1][ptr];
			b = 2.0f * filtered_img[2][ptr];
			a = 3.0f * filtered_img[3][ptr];
			// Position of Extrema
			real s1, s2, D;
			D = b * b - 4.0f * a * c;
			// Check the Existance of Extrema
			if(D > 0){
				D  = sqrt(D);
				// Two Extrema's Positions can be obtained
				s1 = (-b - D) / (2.0f * a);
				s2 = (-b + D) / (2.0f * a);
				if(s1 > s2)std::swap(s1, s2);

				if(s1 >= t1 && s1 < t2){
					add_keypoint(x, y, w, h, ptr, s1, ((2 * a * s1 + b) > 0)?1:-1, keypoints, num, oct);
				}
				if(s2 >= t1 && s2 < t2 && (s2-s1)>2.0){
					add_keypoint(x, y, w, h, ptr, s2, ((2 * a * s2 + b) > 0)?1:-1, keypoints, num, oct);
				}

			} // fi

		} // x
	} // y
}

//*******************************************************************************
// Halfing Image
//*******************************************************************************
void half_img(unsigned char *in, unsigned char *out, int w, int h, int sw, int sh){

	int ptr = 0, sptr;
	for(int y = 1;y < sh-1;y++){
		for(int x = 1;x < sw-1;x++){
			ptr = x + y * sw;
			sptr = x * 2 + y * (2 * w);
			out[ptr] = (
				4 * in[sptr] +
				2 * (in[sptr-w]  +in[sptr+1]  +in[sptr+w]  +in[sptr-1])
				   +(in[sptr-w+1]+in[sptr-w-1]+in[sptr+w+1]+in[sptr+w-1])			
			) / 16.0;
		} // x
	} // y
}

//*******************************************************************************
// Main Routine
//*******************************************************************************
void run(
	unsigned char *in, int w, int h,
	keypoint_t *keypoints, int & num
	){

//#define TIMEMEASURE

#ifdef TIMEMEASURE
		unsigned char *tmp = new unsigned char[w * h];
		memcpy(tmp, in, w * h);
		for(int it = 0;it < 1000;it++){

			memcpy(in, tmp, w * h);
#endif
			clock_t t0;
			t0 = clock();
			filtering_tw = 0;

			num = 0;
			//*******************************************
			// Run Detection per Octave
			//*******************************************
			for(int oct = 0;oct < EIGEN_OCTN;oct++){
				int sw, sh;

				sw = w >> oct;
				sh = h >> oct;

				// don't detect for too small image
				if(sw < 45 || sh < 45)
					continue;

				// Run Detection
				detect(in, sw, sh, keypoints, num, oct);
				// Halfing input image
				half_img(in, in, sw, sh, sw >> 1, sh >> 1);
			}

			int time = clock() - t0;
			printf("detected = %d, total time=%d[msec] (filtering=%d[msec]), time/point=%.4f[msec]\n", num, time, filtering_tw, time/ (real)(num));
			roi_i++;


#ifdef TIMEMEASURE
		}

		delete tmp;
#endif

}




