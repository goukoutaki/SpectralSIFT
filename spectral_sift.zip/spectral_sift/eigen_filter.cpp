//************************************************************************************
//
//  Spectral SIFT Detector Code
//
//  [1]"Scale-space Processing Using Polynomial Representations",
//     Gou Koutaki, Keiichi Uchimura (Kumamoto University), CVPR2014
//
//    Copyright (c) 2014, Gou Koutaki <koutaki@cs.kumamoto-u.ac.jp>
//    All rights reserved.
//
//************************************************************************************
#define _USE_MATH_DEFINES
#include <math.h>
#include <fftw/fftw3.h>
#include <string.h>

#include "eigen_filter.h"

//****************************************************
// Load Eigen-Filters From File
//****************************************************
int load_filter_and_FFT_from_file(
	char *filename, FFTW_COMPLEX * out, 
	int w, int h, int N)
{

	FILE *fp=fopen(filename, "r");
	// open
	if(fp){

		// FFTW works
		FFTW_COMPLEX *tmp;
		FFTW_PLAN	  plan;
		// Alloc works
		tmp = (FFTW_COMPLEX *)FFTW_MALLOC(sizeof(FFTW_COMPLEX)*w*h);
		memset(tmp, 0, sizeof(FFTW_COMPLEX) * w * h);

		//************************************************
		// Load Filter's Co-Efficients
		int x, y, ix, iy, ptr;
		double value;
		int hw, hh;
		hw = w / 2;
		hh = h / 2;
		for(y = -N;y <= N;y++){
			iy = y;
			if(iy < 0)iy = h + iy;		
			for(x = -N;x <= N;x++){
				ix = x;
				if(ix < 0)ix = w + ix;	
				fscanf(fp, "%lf,", &value);
				ptr = ix + iy * w;
				if(abs(x)<=hw&&abs(y)<=hh){
					tmp[ptr][0] = value;
					tmp[ptr][1] = 0.0;
				}
			};//x			
		};//y
		//************************************************

		// RUN FFT
		plan = FFTW_DFT(h, w, tmp, out, FFTW_FORWARD, FFTW_MEASURE);	
		FFTW_EXCUTE(plan);

		// Free works
		FFTW_FREE(tmp);
		fclose(fp);
		return 1;
	}

	return 0;
}
