//*******************************************************************************
//
// recall - precision�@�Ȑ��`��v���O���� by g.koutaki 2013.10.23
//  
//
// �y�����̗���z
// �@�L�[�|�C���g�ǂݍ���
// �A�����z���O���t�B�擾
// �B�L�[�|�C���g�d�ˍ��킹�E�~�}�b�`���O�@�����y�A���o(#correspondences)
// �C�������l�ݒ�
// �D�}�b�`���O�E�Ή��֌W�Ƃ�E����(#correct num, #false num)������
// �Erecall      = #correct / #correspondences
// �F1-precision = #false / (#correct + #false)
//*******************************************************************************

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <opencv2/opencv.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/nonfree/nonfree.hpp>
using namespace cv;


#define max(a, b) (a<b?b:a)
#define min(a, b) (a>b?b:a)


/** FEATURE_OXFD <BR> FEATURE_LOWE */
enum feature_type
{
	FEATURE_OXFD,
	FEATURE_LOWE,
};
/** FEATURE_FWD_MATCH <BR> FEATURE_BCK_MATCH <BR> FEATURE_MDL_MATCH */
enum feature_match_type
{
	FEATURE_FWD_MATCH,
	FEATURE_BCK_MATCH,
	FEATURE_MDL_MATCH,
};
/** max feature descriptor length */
#define FEATURE_MAX_D 128

struct pt2_t {
	int x, y;
};

struct feature
{
	double x;                      /**< x coord */
	double y;                      /**< y coord */
	double a;                      /**< Oxford-type affine region parameter */
	double b;                      /**< Oxford-type affine region parameter */
	double c;                      /**< Oxford-type affine region parameter */
	double scl;                    /**< scale of a Lowe-style feature */
	double ori;                    /**< orientation of a Lowe-style feature */
	int d;                         /**< descriptor length */
	double descr[FEATURE_MAX_D];   /**< descriptor */
	int type;                      /**< feature type, OXFD or LOWE */
	int category;                  /**< all-purpose feature category */
	struct feature* fwd_match;     /**< matching feature from forward image */
	struct feature* bck_match;     /**< matching feature from backmward image */
	struct feature* mdl_match;     /**< matching feature from model */
	void* feature_data;            /**< user-definable data */
	pt2_t img_pt;
	pt2_t mdl_pt;
};

int import_lowe_features( char* filename, struct feature** features )
{
	struct feature* f;
	int i, j, n, d;
	double x, y, s, o, dv;
	FILE* file;


	if( ! ( file = fopen( filename, "r" ) ) )
	{
		fprintf( stderr, "Warning: error opening %s, %s, line %d\n",
			filename, __FILE__, __LINE__ );
		return -1;
	}

	/* read number of features and dimension */
	if( fscanf( file, " %d %d ", &n, &d ) != 2 )
	{
		fprintf( stderr, "Warning: file read error, %s, line %d\n",
				__FILE__, __LINE__ );
		return -1;
	}
	if( d > FEATURE_MAX_D )
	{
		fprintf( stderr, "Warning: descriptor too long, %s, line %d\n",
				__FILE__, __LINE__ );
		return -1;
	}

	f = (feature*)calloc( n, sizeof(struct feature) );
	for( i = 0; i < n; i++ )
	{
		/* read affine region parameters */
		if( fscanf( file, " %lf %lf %lf %lf ", &y, &x, &s, &o ) != 4 )
		{
			fprintf( stderr, "Warning: error reading feature #%d, %s, line %d\n",
					i+1, __FILE__, __LINE__ );
			free( f );
			return -1;
		}
		f[i].img_pt.x = f[i].x = x;
		f[i].img_pt.y = f[i].y = y;
		f[i].scl = s;
		f[i].ori = o;
		f[i].d = d;
		f[i].type = FEATURE_LOWE;

		/* read descriptor */
		for( j = 0; j < d; j++ )
		{
			if( ! fscanf( file, " %lf ", &dv ) )
			{
				fprintf( stderr, "Warning: error reading feature descriptor" \
						" #%d, %s, line %d\n", i+1, __FILE__, __LINE__ );
				free( f );
				return -1;
			}
			f[i].descr[j] = dv;
		}

		f[i].a = f[i].b = f[i].c = 0;
		f[i].category = 0;
		f[i].fwd_match = f[i].bck_match = f[i].mdl_match = NULL;
		f[i].mdl_pt.x = f[i].mdl_pt.y = -1;
	}

	if( fclose(file) )
	{
		fprintf( stderr, "Warning: file close error, %s, line %d\n",
				__FILE__, __LINE__ );
		free( f );
		return -1;
	}

	*features = f;
	return n;
}


// �z���O���t�B�ǂݍ���
void load_homography(char *filename, double *H){

	FILE *fp=fopen(filename, "r");

	if(fp){
		for(int i = 0;i < 9;i++)
			fscanf(fp,"%lf", &H[i]);
		fclose(fp);
		for(int i = 0;i < 9;i++)
			H[i] /= H[8];
	}
}

void linearizationHom(double *H, double cx, double cy, double *A){

	double p1 = H[0] * cx + H[1] * cy + H[2];
	double p2 = H[3] * cx + H[4] * cy + H[5];
	double p3 = H[6] * cx + H[7] * cy + H[8];
	double p3_2 = p3 * p3;

	A[0] = H[0] / p3 - p1 * H[6] / p3_2;
	A[1] = H[1] / p3 - p1 * H[7] / p3_2;
	A[2] = H[3] / p3 - p1 * H[6] / p3_2;
	A[3] = H[4] / p3 - p1 * H[7] / p3_2;
}



double Det3x3(double * m)
{
    return m[0]*m[4]*m[8]+m[3]*m[7]*m[2]+m[6]*m[1]*m[5]
          -m[0]*m[7]*m[5]-m[6]*m[4]*m[2]-m[3]*m[1]*m[8];
}
 
/*
 0 1 2 0 3 6
 3 4 5 1 4 7 
 6 7 8 2 5 8

*/

void Inv3x3(double *m, double *invm)
{
	double det = Det3x3(m);
	double inv_det = 1.0/det;

	invm[0] = inv_det*(m[4]*m[8]-m[5]*m[7]);
	invm[1] = inv_det*(m[2]*m[7]-m[1]*m[8]);
	invm[2] = inv_det*(m[1]*m[5]-m[2]*m[4]);

	invm[3] = inv_det*(m[5]*m[6]-m[3]*m[8]);
	invm[4] = inv_det*(m[0]*m[8]-m[2]*m[6]);
	invm[5] = inv_det*(m[2]*m[3]-m[0]*m[5]);

	invm[6] = inv_det*(m[3]*m[7]-m[4]*m[6]);
	invm[7] = inv_det*(m[1]*m[6]-m[0]*m[7]);
	invm[8] = inv_det*(m[0]*m[4]-m[1]*m[3]);

}


void calc_ellipse_param(double s, double *H, double cx, double cy, double & a, double &ab, double &b, double &tx, double &ty){

	double A[4];
	linearizationHom(H, cx, cy, A);

	double f = (A[1]*A[2]-A[0]*A[3])*(A[1]*A[2]-A[0]*A[3]);
	a  =  s * (A[2]*A[2]+A[3]*A[3]) / f;
	ab = -s * (A[0]*A[2]+A[1]*A[3]) / f;
	b  =  s * (A[0]*A[0]+A[1]*A[1]) / f;

	double tz = cx * H[6] + cy * H[7] + H[8];
	tx = (cx * H[0] + cy * H[1] + H[2]) / tz;
	ty = (cx * H[3] + cy * H[4] + H[5]) / tz;
}


double calc_overlap(double x1, double y1, double s1, double x2, double y2, double s2, double *H, double a, double ab, double b, double cx, double cy){

	double s12 = s1 * s1; 
	double s22 = s2 * s2; 
	double u, v, step;
	double r2 = s1 * 1.5 + s2;
	double rx, ry, z, d1, d2;

	step = s2 / 10.0;

	double A, B, AandB, AorB;

	// �z���O���t�B�t���Z�ŉ摜�P�̍��W�n�ɕϊ�
	z  =  x1 * H[6] + y1 * H[7] + H[8];
	rx = (x1 * H[0] + y1 * H[1] + H[2]) /z;
	ry = (x1 * H[3] + y1 * H[4] + H[5]) /z;

	double L = sqrt((rx-x2)*(rx-x2)+(ry-y2)*(ry-y2));

	if(L >(s2 + s1 * 1.5))
		return 1.0;

	A = B = AandB = AorB = 0;

	for(v = y2 - r2;v <= y2 + r2; v += step){
		for(u = x2 - r2;u <= x2 + r2; u += step){

			z = (H[1]*H[3] - H[0]*H[4] - v*H[1]*H[6] + u*H[4]*H[6] + v*H[0]*H[7] - u*H[3]*H[7]);
			// �z���O���t�B�t���Z�ŉ摜�P�̍��W�n�ɕϊ�
			rx = -((-H[2]*H[4] + H[1]*H[5] + v*H[2]*H[7] - u*H[5]*H[7] - v*H[1]*H[8] + u*H[4]*H[8])/z);
			ry = +((-H[2]*H[3] + H[0]*H[5] + v*H[2]*H[6] - u*H[5]*H[6] - v*H[0]*H[8] + u*H[3]*H[8])/z);
			// �~�ɓ����Ă��邩
			d1 = (rx - x1)*(rx - x1)+(ry - y1)*(ry - y1);
			d2 = ( u - x2)*( u - x2)+( v - y2)*( v - y2);
			if(d1 < s12)
				A++;
			if(d2 < s22)
				B++;
			if(d1 < s12 && d2 < s22)
				AandB++;
			/*
			if(a * (u-cx)*(u-cx)+ ab * (u-cx)*(v-cy) + b * (v-cy)*(v-cy) < 1.0){
				A++;
			}
			*/

		}
	}
	AorB = A + B - AandB;

	double epsiron = 1.0;
	
	if(AorB > 0)
		epsiron = 1.0 - AandB / AorB;

	return epsiron;
}

void remove_outside_ft(feature *ft, int & ft_n, int w, int h, double *H){

	int out_n = 0;
	for(int i = 0;i < ft_n;i++){
		double x, y, px,py,pz, dx, dy;
		x = ft[i].x;
		y = ft[i].y;
		px = x * H[0] + y * H[1] + H[2];
		py = x * H[3] + y * H[4] + H[5];
		pz = x * H[6] + y * H[7] + H[8];
		dx = px / pz;
		dy = py / pz;
		if(x > 0 && y > 0 && x < w && y < h){
			ft[out_n] = ft[i];
			out_n++;
		}
	}
	printf("remove %d->%d\n", ft_n, out_n);
	ft_n = out_n;
}


// ���C�����[�`��
int main(int argc, char *argv[]){

	if(argc!=8){
		printf("usage: evaluate.exe key1 key2 homography output in1 in2\n");
		return 0;
	}
	feature *ft1 = new feature[10000];
	feature *ft2 = new feature[10000];
	int ft1_n, ft2_n;
	int finverse = 0;
	// �L�[�|�C���g�ǂݍ���
	ft1_n = import_lowe_features(argv[1], &ft1);
	ft2_n = import_lowe_features(argv[2], &ft2);
	char file1[256], file2[256];
	strcpy(file1, argv[5]);
	strcpy(file2, argv[6]);

	if(ft2_n < ft1_n){

		finverse = 1;
		ft1_n = import_lowe_features(argv[2], &ft1);
		ft2_n = import_lowe_features(argv[1], &ft2);
		strcpy(file1, argv[6]);
		strcpy(file2, argv[5]);
	}
	// �z���O���t�B�ǂݍ���
	double H[9] = {1,0,0, 0,1,0, 0,0,1}, invH[9];
	load_homography(argv[3], H);
	if(finverse){
		Inv3x3(H, invH);
		memcpy(H, invH, sizeof(double) * 9);
	}
	//
	int w1, h1, w2, h2;
	Mat in1 = imread(file1);
	Mat in2 = imread(file2);
	w1 = in1.cols;
	h1 = in1.rows;
	w2 = in2.cols;
	h2 = in2.rows;
	remove_outside_ft(ft1, ft1_n, w2, h2, H);
	// #correspondences�����߂�(�����̃y�A)
	int correspondences_n = 0;

	for(int i = 0;i < ft1_n;i++){
		float fac = 3.0;
		ft1[i].scl *= fac;
	}
	for(int i = 0;i < ft2_n;i++){
		float fac = 3.0;
		ft2[i].scl *= fac;
	}

	Mat outimg(Size(w1+w2, max(h1,h2)), CV_8UC3);
	Mat roi1(outimg, Rect(0,  0, w1, h1));
	Mat roi2(outimg, Rect(w1, 0, w2, h2));
	in1.copyTo(roi1);
	in2.copyTo(roi2);


	printf("key1=%d, key2=%d\n", ft1_n, ft2_n);
	int cortbl[1000] = {0};

	for(int i = 0;i < ft1_n;i++){
		printf("%d/%d\r", i, ft1_n);

		double a, ab, b, tx, ty, cx, cy;
		cx =  ft1[i].x;
		cy =  ft1[i].y;
		calc_ellipse_param(1.0 / (ft1[i].scl*ft1[i].scl), H, ft1[i].x, ft1[i].y, a, ab, b, tx, ty); 

		int min_j = 0;
		double min_epsiron = 1.0;
		for(int j = 0;j < ft2_n;j++){
			if(cortbl[j])
				continue;

			double epsiron = calc_overlap(ft1[i].x, ft1[i].y, ft1[i].scl, ft2[j].x, ft2[j].y, ft2[j].scl, H, a, ab, b, tx, ty);
			// �������l�ȉ��Ȃ�΁Ai��j�͑Ή��t�����Ă���
			if(epsiron < min_epsiron){
				min_epsiron = epsiron;
				min_j = j;
				//printf("(%.1f, %.1f, %.1f)-(%.1f, %.1f, %.1f)\n", ft1[i].x, ft1[i].y, ft1[i].scl, ft2[j].x, ft2[j].y, ft2[j].scl);
			}
		} // j
		if(min_epsiron < 0.5){
			cortbl[min_j] = 1;
			correspondences_n++;
			Scalar Col(rand()%255, rand()%255, 128+rand()%128);
			circle(outimg, Point(cx, cy),                ft1[i].scl / 3.0, Col);
			circle(outimg, Point(w1+ft2[min_j].x, ft2[min_j].y), ft2[min_j].scl / 3.0, Col);
			line(outimg, Point(cx, cy), Point(w1+ft2[min_j].x, ft2[min_j].y), Col);
		}
	} // i

	printf("repeatablity=%d/%d=%.2f\n", correspondences_n, min(ft1_n, ft2_n), 100.0 * correspondences_n/ (double)min(ft1_n, ft2_n));

	imwrite(argv[7], outimg);

	FILE *fp=fopen(argv[4], "a");
	fprintf(fp, "%s %s %d %d %.2f\n", argv[1], argv[2], correspondences_n, min(ft1_n, ft2_n), 100.0 * correspondences_n/ (double)min(ft1_n, ft2_n) );
	fclose(fp);

	delete ft1;
	delete ft2;

	return 0;
}

